import { IsOptional, IsNotEmpty } from 'class-validator';

export class UpdateLocationDto {
  @IsOptional()
  @IsNotEmpty()
  cep?: string;

  @IsOptional()
  latitude?: number;

  @IsOptional()
  longitude?: number;
}
