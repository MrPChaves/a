import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  address: string;

  @Column()
  number: string;

  @Column()
  cep: string;

  @Column()
  email: string;

  @Column()
  comorbidity: string;

  @Column()
  password: string;
}
