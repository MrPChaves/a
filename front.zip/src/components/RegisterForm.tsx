// src/components/RegisterForm.tsx
import React, { useState } from 'react';

interface RegisterFormProps {
  onRegister: (marker: { id: number; lat: number; lng: number }) => void;
}

const RegisterForm: React.FC<RegisterFormProps> = ({ onRegister }) => {
  const [lat, setLat] = useState<number>(0);
  const [lng, setLng] = useState<number>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRegister({ id: Date.now(), lat, lng });
    setLat(0);
    setLng(0);
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Latitude:
        <input
          type="number"
          value={lat}
          onChange={(e) => setLat(Number(e.target.value))}
          required
        />
      </label>
      <label>
        Longitude:
        <input
          type="number"
          value={lng}
          onChange={(e) => setLng(Number(e.target.value))}
          required
        />
      </label>
      <button type="submit">Cadastrar Pino</button>
    </form>
  );
};

export default RegisterForm;
