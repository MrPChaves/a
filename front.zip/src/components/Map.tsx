// src/components/Map.tsx
import React, { useEffect, useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import axios from 'axios';

const containerStyle = {
  width: '100%',
  height: '90vh'
};

const center = {
  lat: -15.7801, // Defina a latitude central que deseja exibir
  lng: -47.9292  // Defina a longitude central que deseja exibir
};

const Map: React.FC = () => {
  const [locations, setLocations] = useState<any[]>([]); // Array para armazenar as localizações

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const response = await axios.get('http://localhost:3002/locations');
        setLocations(response.data); // Atualiza o estado com os dados recebidos
      } catch (error) {
        console.error('Erro ao buscar localizações:', error);
      }
    };

    fetchLocations(); // Chama a função para buscar as localizações
  }, []);

  return (
    <LoadScript googleMapsApiKey="AIzaSyCm16RPmdYidSTlE57-I-w1GktTJBOWgdI">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={7}
      >
        {locations.map(location => (
          <Marker 
            key={location.id} 
            position={{ lat: parseFloat(location.latitude), lng: parseFloat(location.longitude) }} 
            label={location.name} // Se você quiser mostrar o nome como label
          />
        ))}
      </GoogleMap>
    </LoadScript>
  );
};

export default Map;
