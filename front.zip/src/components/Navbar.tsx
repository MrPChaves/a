// src/components/Navbar.tsx

import './Navbar.css';

const Navbar = () => {
    const handleThemeToggle = () => {
        // Lógica para alternar temas
    };

    return (
        <nav className="navbar">
            <h1>Meu Aplicativo</h1>
            <div className="navbar-links">
                <a href="/" className="navbar-link">Home</a>
                <a href="/register" className="navbar-link">Cadastrar</a>
                <a href="/about" className="navbar-link">Sobre</a>
                <a href="/contact" className="navbar-link">Contato</a>
            </div>
            <button className="theme-toggle" onClick={handleThemeToggle}>
                🌙
            </button>
        </nav>
    );
};

export default Navbar;
