document.addEventListener('DOMContentLoaded', () => {
    const collections = document.getElementById('collections');
    const leftBtn = document.getElementById('left-btn');
    const rightBtn = document.getElementById('right-btn');

    leftBtn.addEventListener('click', () => {
        collections.scrollBy({
            top: 0,
            left: -200,
            behavior: 'smooth'
        });
    });

    rightBtn.addEventListener('click', () => {
        collections.scrollBy({
            top: 0,
            left: 200,
            behavior: 'smooth'
        });
    });
});

document.querySelectorAll('.like-btn').forEach(button => {
    button.addEventListener('click', function() {
        const likeCountSpan = this.previousElementSibling;
        let likeCount = parseInt(likeCountSpan.textContent, 10);
        likeCount += 1;
        likeCountSpan.textContent = likeCount;
    });
});
