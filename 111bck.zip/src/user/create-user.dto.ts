import { IsString, IsEmail, IsNotEmpty } from 'class-validator';

export class CreateUserDto {
  @IsNotEmpty()
  @IsString()
  name: string;

  @IsNotEmpty()
  @IsString()
  address: string;

  @IsNotEmpty()
  @IsString()
  number: string; // Atributo deve ser string se você está recebendo um número como string

  @IsNotEmpty()
  @IsString()
  cep: string;

  @IsNotEmpty()
  @IsEmail()
  email: string;

  @IsNotEmpty()
  @IsString()
  comorbidity: string;

  @IsNotEmpty()
  @IsString()
  password: string;
}
