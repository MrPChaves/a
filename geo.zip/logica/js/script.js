// Inicializa o mapa
const map = L.map('map').setView([-23.5505, -46.6333], 10); // Coordenadas de São Paulo

// Adiciona a camada do mapa usando OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
}).addTo(map);

// Função para obter os dados da API e adicionar pinos ao mapa
async function fetchLocations() {
    try {
        const response = await fetch('http://localhost:3002/locations');

        // Verifique se a resposta está ok
        if (!response.ok) {
            throw new Error('Erro na rede: ' + response.statusText);
        }

        const locations = await response.json();

        // Log para depurar as localizações recebidas
        console.log('Localizações recebidas:', locations);

        locations.forEach(location => {
            // Verifica se as coordenadas são válidas
            if (location.latitude && location.longitude) {
                // Cria um pino para cada localização
                L.marker([location.latitude, location.longitude])
                    .addTo(map)
                    .bindPopup(`<b>${location.name}</b><br>${location.description}`);
                console.log(`Pino adicionado: ${location.name} em [${location.latitude}, ${location.longitude}]`);
            } else {
                console.warn('Coordenadas inválidas para a localização:', location);
            }
        });
    } catch (error) {
        console.error('Erro ao buscar localizações:', error);
    }
}

// Chama a função para buscar e exibir os pinos
fetchLocations();

// Função para alternar o tema
function toggleTheme() {
    const body = document.body;
    body.classList.toggle('dark-theme');

    const themeToggleIcon = document.querySelector('.theme-toggle');
    themeToggleIcon.innerHTML = body.classList.contains('dark-theme') ? '🌙' : '🌞'; // Troca o ícone
}

// Função para mostrar a tela de cadastro
function showRegistration() {
    document.getElementById('registration').style.display = 'block'; // Mostra o formulário de cadastro
    document.getElementById('map').style.display = 'none'; // Esconde o mapa
}

// Função para esconder a tela de cadastro
function hideRegistration() {
    document.getElementById('registration').style.display = 'none'; // Esconde o formulário de cadastro
    document.getElementById('map').style.display = 'block'; // Mostra o mapa
}

// Função para mostrar a tela inicial (mapa)
function showHome() {
    document.getElementById('registration').style.display = 'none'; // Esconde o formulário de cadastro
    document.getElementById('map').style.display = 'block'; // Mostra o mapa
}



// Chama a função para mostrar o mapa inicialmente
showHome();
