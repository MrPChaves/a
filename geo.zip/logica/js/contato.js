// contato.js
function sendEmail(event) {
    event.preventDefault(); // Impede o envio padrão do formulário

    const form = document.getElementById('contactForm');
    const formData = new FormData(form);

    // Converte FormData para um objeto simples
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        whatsapp: formData.get('whatsapp'),
        subject: formData.get('subject')
    };

    // Aqui você pode fazer a solicitação para o seu servidor ou serviço de envio de e-mail
    fetch('/api/send-email', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (response.ok) {
            alert('Email enviado com sucesso!');
            form.reset(); // Limpa o formulário após o envio
        } else {
            alert('Erro ao enviar o email. Tente novamente mais tarde.');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro ao enviar o email. Tente novamente mais tarde.');
    });
}
