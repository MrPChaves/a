// Função para registrar usuário
async function registerUser(event) {
    event.preventDefault(); // Evita o envio padrão do formulário

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;
    const number = document.getElementById('number').value;
    const cep = document.getElementById('cep').value;
    const comorbidity = document.getElementById('comorbidity').value;
    const password = document.getElementById('password').value;

    try {
        // Faz a chamada para a API para registrar o usuário
        const response = await fetch('http://localhost:3002/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                name,
                email,
                address,
                number,
                cep,
                comorbidity,
                password
            }),
        });

        if (response.ok) {
            alert('Usuário cadastrado com sucesso!');
            document.getElementById('registrationForm').reset(); // Limpa o formulário
        } else {
            const errorText = await response.text(); // Tenta pegar a resposta como texto
            alert(`Erro ao cadastrar usuário: ${errorText}`);
        }
    } catch (error) {
        console.error('Erro ao tentar cadastrar o usuário:', error);
        alert('Erro de rede ao cadastrar usuário.');
    }
}

// Adiciona o evento de submit ao formulário
document.getElementById('registrationForm').addEventListener('submit', registerUser);
