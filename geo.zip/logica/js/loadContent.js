// logica/js/loadContent.js
function loadSection(section) {
    const contentDiv = document.getElementById('content');

    fetch(`sections/${section}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar a seção.');
            }
            return response.text();
        })
        .then(html => {
            contentDiv.innerHTML = html;
        })
        .catch(error => {
            console.error('Erro:', error);
            contentDiv.innerHTML = `<h2>Erro ao carregar o conteúdo.</h2>`;
        });
}

// Carregar a seção inicial ao abrir a página
window.onload = function() {
    loadSection('home.html');
};
