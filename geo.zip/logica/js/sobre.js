// Função para mostrar a seção Sobre
function showAbout() {
    document.getElementById('about').style.display = 'block'; // Mostra a seção Sobre
    document.getElementById('registration').style.display = 'none'; // Esconde a tela de cadastro
    document.getElementById('contact').style.display = 'none'; // Esconde a seção Contato
    document.getElementById('map').style.display = 'none'; // Esconde o mapa
}