import React from 'react';

const Home: React.FC = () => {
  return (
    <>
            
                <meta charSet="UTF-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>Hd do Designer</title>
                <link rel="stylesheet" href="styles.css" />
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
            
      <header>
        <div className="top-bar">
          <div className="logo">
            <img src="../assets/LOGO.png" alt="Logo Hd do Designer" className="logo-img" />
          </div>
          <div className="search-container">
            <input type="text" id="search-bar" placeholder="Pesquise alguma coisa..." />
            <button id="search-btn">Buscar</button>
          </div>
          <div className="header-buttons">
            <a href="../premium/index.html" className="btn">Assine o Premium</a>
            <a href="../cadastro/index.html" className="btn">Cadastre-se</a>
            <a href="../login/index.html" className="btn">Login</a>
          </div>
        </div>
        <nav>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Coleções</a></li>
            <li><a href="#">PSD</a></li>
            <li><a href="#">PNG</a></li>
            <li><a href="#">Fotos</a></li>
            <li><a href="#">Vetores</a></li>
            <li><a href="#">Texturas</a></li>
            <li><a href="#">Vídeos</a></li>
            <li><a href="#">Apresentações</a></li>
            <li><a href="#">Mockups</a></li>
            <li><a href="#">Mais categorias</a></li>
          </ul>
        </nav>
      </header>
      <main>
        <section className="hero">
          <div className="hero-content">
            <h1>Aumente sua <span className="highlight">produtividade</span>.</h1>
            <p>Recursos para turbinar seus projetos.</p>
            <p>Descubra conteúdo visual de alta qualidade para seus projetos de design. Faça o download do que precisar, diretamente da nuvem, garantindo o melhor custo-benefício.</p>
            <div className="hero-buttons">
              <button className="btn-hero">Conheça o Premium</button>
              <button className="btn-hero">Cadastre-se grátis</button>
            </div>
          </div>
        </section>
        <div className="collections-section">
          <h2>Coleções</h2>
          <div className="collections-carousel">
            <button className="carousel-btn left" id="left-scroll">{"<"}</button>
            <div className="collections">
              <div className="collection-item">
                <img src="./assets/seletor/comida-japonesa.jpg" alt="Comida Japonesa" />
                <p>Comida Japonesa</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/moveis-planejados.jpeg" alt="Móveis Planejados" />
                <p>Móveis Planejados</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/carros.jpeg" alt="Carros Esportivos" />
                <p>Carros Esportivos</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/barcos.jpeg" alt="Barcos de Luxo" />
                <p>Barcos de Luxo</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/instrumentos-musicais.jpg" alt="Instrumentos Musicais" />
                <p>Instrumentos Musicais</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/flores.jpg" alt="Flores" />
                <p>Flores</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/alegria.jpeg" alt="Alegria" />
                <p>Alegria</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/esportes.jpeg" alt="Esportes" />
                <p>Esportes</p>
              </div>
              <div className="collection-item">
                <img src="./assets/seletor/colections.jpg" alt="Ver Mais" />
                <p>Ver Mais</p>
              </div>
            </div>
            <button className="carousel-btn right" id="right-scroll">{">"}</button>
          </div>
        </div>
        <section className="new-cards-section">
          <h2>Novos Cards</h2>
          <div className="cards-container">
            <div className="card">
              <img src="./assets/pan.jpg" alt="Card 1" />
              <div className="badge premium">Premium</div>
              <div className="likes">
                <span className="like-count">100</span>
                <button className="like-btn"><i className="fas fa-heart"></i></button>
              </div>
              <div className="title-badge">Panfleto</div>
            </div>
            <div className="card">
              <img src="./assets/pan2.jpg" alt="Card 2" />
              <div className="badge free">Free</div>
              <div className="likes">
                <span className="like-count">150</span>
                <button className="like-btn"><i className="fas fa-heart"></i></button>
              </div>
              <div className="title-badge">Cartão</div>
            </div>
            <div className="card">
              <img src="./assets/pan3.png" alt="Card 3" />
              <div className="badge premium">Premium</div>
              <div className="likes">
                <span className="like-count">100</span>
                <button className="like-btn"><i className="fas fa-heart"></i></button>
              </div>
              <div className="title-badge">Foto PNG</div>
            </div>
            <div className="card">
              <img src="./assets/pan4.jpeg" alt="Card 4" />
              <div className="badge free">Free</div>
              <div className="likes">
                <span className="like-count">150</span>
                <button className="like-btn"><i className="fas fa-heart"></i></button>
              </div>
              <div className="title-badge">Layout</div>
            </div>
            {/* Continue adding more cards as needed */}
          </div>
        </section>
      </main>
    </>
  );
}

export default Home;
