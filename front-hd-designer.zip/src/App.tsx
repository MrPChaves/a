import React from 'react';
import Home from './pages/home';

const App: React.FC = () => {
  return (
    <div>
      <Home />
    </div>
  );
};

export default App;
