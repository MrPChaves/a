// src/pages/index.tsx
import React from 'react';
import ContadorFimOferta from '../components/ContadorFimOferta';
import FotoAction from '../components/FotoAction';
import PlayerDeVideoPrivado from '../components/PlayerDeVideoPrivado';
import BotaoMeTornarDesejado from '../components/BotaoMeTornardesejado'; // Corrigido o nome do arquivo
import TextoMarquee from '../components/TextoMarquee';
import CardsSection from '../components/CardsSection';
import EntregarMinhaExperiencia from '../components/EntregarMinhaExperiencia';
import BeneficiosSection from '../components/BeneficiosSection';
import AboutMeSection from '../components/AboutMeSection';
import CardOferta from '../components/CardOferta';
import FAQSection from '../components/FAQSection';
import Rodape from '../components/Rodape';
import JoinGroupSection from '../components/junteseaogrupo';
import styles from '../styles/page.module.css'; // Corrigido o nome do arquivo CSS Module
import Image from 'next/image';

const Home: React.FC = () => {
  const handleButtonClick = () => {
    // Lógica a ser executada quando o botão for clicado
    alert('Botão clicado!');
  };

  return (
    <main className={styles.main}>
      <ContadorFimOferta />
      <FotoAction 
        imageSrc="/patrick.jpeg" // Caminho corrigido para a imagem local
        text=""/>
      <p style={{textAlign: 'center', top: '30px', fontSize: '48px', color: '#93f1d2', position: 'relative', marginTop: '30px'}}>
      Descubra o <strong>Segredo</strong> para programadores se tornarem <strong>Desejados</strong> pelo mercado e pelas empresas.
    <strong> Encante</strong> recrutadores e receba <strong>Elogios</strong> dos entrevistadores.
      Receba convites semanais para entrevistas. Use gatilhos importantes para <strong>aprovação</strong>
    </p>
      
      <h1 style={{textAlign: 'center', top: '50px', color: '#93f1d2', position: 'relative', marginTop: '130px'}}><u>Assista o vídeo e entenda:</u></h1>
      
      <PlayerDeVideoPrivado
        imageUrl="https://www.iconsdb.com/icons/preview/green/video-play-4-xxl.png"
        text="Descubra o segredo dos criativos que vendem. Imagens e vídeos com gatilhos mentais para você vender TON todos os dias."
        videoUrl="https://www.youtube.com/embed/VIDEO_ID"
      />
      <BotaoMeTornarDesejado onClick={handleButtonClick} />
      <TextoMarquee />
      <CardsSection />
      <EntregarMinhaExperiencia />
      <BotaoMeTornarDesejado onClick={handleButtonClick} />
      <BeneficiosSection />
      <CardOferta />
      <AboutMeSection />
      <FAQSection />
      <JoinGroupSection />
      <Rodape />    
      <div className={styles.content}>
        {/* Seu conteúdo principal aqui */}
      </div>
    </main>
  );
};

export default Home;
