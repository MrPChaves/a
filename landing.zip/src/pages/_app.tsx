// src/pages/_app.tsx
import '../styles/globals.css'; // Importa os estilos globais
import '@fortawesome/fontawesome-free/css/all.min.css'; // Importa o Font Awesome local
import type { AppProps } from 'next/app';

function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}

export default MyApp;
