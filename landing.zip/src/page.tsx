import { useEffect, useState } from 'react';

export default function Home() {
  const [clientSide, setClientSide] = useState(false);

  useEffect(() => {
    setClientSide(true);
  }, []);

  return (
    clientSide && (
      <main>
        {/* Seu código JSX aqui */}
      </main>
    )
  );
}
