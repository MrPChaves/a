// src/components/ImageTextComponent.tsx
import React from 'react';
import Image from 'next/image'; // Importando o componente Image do Next.js
import styles from '../styles/FotoAction.module.css'; // Importando o arquivo CSS Module

interface ImageTextComponentProps {
  imageSrc: string; // Renomeado para imageSrc para clareza
  text: string;
}

const ImageTextComponent: React.FC<ImageTextComponentProps> = ({ imageSrc, text }) => {
  return (
    <div className={styles.container}>
      <div className={styles.imageWrapper}>
        <Image src={imageSrc} alt="Imagem Descritiva" layout="fill" objectFit="cover" />
      </div>
      <br></br><br></br><br></br>
      <div className={styles.textWrapper}>
        <p className={styles.text}>
        {text}
      </p>
    </div>
    </div>
  );
};

export default ImageTextComponent;
