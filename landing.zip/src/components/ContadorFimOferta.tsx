// src/components/ContadorFimOferta.tsx
import React, { useEffect, useState } from 'react';
import styles from '../styles/ContadorFimOferta.module.css';

const ContadorFimOferta: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number } | null>(null);

  const calculateTimeLeft = () => {
    const difference = +new Date("2028-12-31T23:59:59") - +new Date();
    let timeLeft = { hours: 0, minutes: 0, seconds: 0 };

    if (difference > 0) {
      timeLeft = {
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }

    return timeLeft;
  };

  useEffect(() => {
    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (timeLeft === null) {
    return <div className={styles.container}>Loading...</div>; // Mensagem de carregamento
  }

  return (
    <div className={styles.container}>
      <span>ESTA OFERTA TERMINA EM:</span><br></br>
      <div className={styles.timer}>
        <div className={styles.timeBox}>
          <p>{String(timeLeft.hours).padStart(2, '0')}</p>
          <span>Horas</span>
        </div>
        <div className={styles.timeBox}>
          <p>{String(timeLeft.minutes).padStart(2, '0')}</p>
          <span>Minutos</span>
        </div>
        <div className={styles.timeBox}>
          <p>{String(timeLeft.seconds).padStart(2, '0')}</p>
          <span>Segundos</span>
        </div>
      </div>
    </div>
  );
};

export default ContadorFimOferta;
