// src/components/EntregarMinhaExperiencia.tsx
import React from 'react';
import styles from '../styles/EntregarMinhaExperiencia.module.css'; // Certifique-se de criar este arquivo CSS

const EntregarMinhaExperiencia: React.FC = () => {
  return (
    <section className={styles.sectionContainer}>
      <div className={styles.container}>
        <h2 className={styles.title}>Vou te entregar minha experiência em processos seletivos, entrevistas comportamentais e entrevistas entrevistas técnicas!</h2>
        <br></br><br></br><br></br>
        <div className={styles.cardsContainer}>
          <div className={styles.card}>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7cX-K1Oa86K5euMpACx97SnqyIbOqTGMaOQ&s" alt="Imagem 1" className={styles.image} />
            <p className={styles.text}>Descrição do serviço 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
          <br></br><br></br><br></br>
          <div className={styles.card}>
            <img src="https://cdn.corporatefinanceinstitute.com/assets/hard-skills-768x512.jpeg" alt="Imagem 2" className={styles.image} />
            <p className={styles.text}>Descrição do serviço 2. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
          <br></br><br></br><br></br>
          <div className={styles.card}>
            <img src="https://www.springboard.com/blog/wp-content/uploads/2022/09/programmng-language.jpg" alt="Imagem 3" className={styles.image} />
            <p className={styles.text}>Descrição do serviço 3. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EntregarMinhaExperiencia;
