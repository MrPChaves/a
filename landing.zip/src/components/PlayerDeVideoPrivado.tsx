// src/components/PlayerDeVideoPrivado.tsx
import React, { useState } from 'react';
import styles from '../styles/PlayerDeVideoPrivado.module.css'; // Importando o arquivo CSS Module
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay } from '@fortawesome/free-solid-svg-icons';

interface PlayerDeVideoPrivadoProps {
  imageUrl: string;
  text: string;
  videoUrl: string; // URL do vídeo do YouTube
}

const PlayerDeVideoPrivado: React.FC<PlayerDeVideoPrivadoProps> = ({ imageUrl, text, videoUrl }) => {
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  const handlePlayClick = () => {
    setIsVideoOpen(true);
  };

  const handleCloseVideo = () => {
    setIsVideoOpen(false);
  };

  return (
    <div className={styles.container}>
      
      <p className={styles.text}>
        <br /><br /><br /><br /><br /><br /><br /><br />
        
      </p>
      <div className={styles.videoWrapper} onClick={handlePlayClick}>
        <FontAwesomeIcon icon={faPlay} className={styles.playIcon} />
      </div>

      {isVideoOpen && (
        <div className={styles.modal}>
          <div className={styles.modalContent}>
            <span className={styles.close} onClick={handleCloseVideo}>&times;</span>
            <iframe
              width="900"
              height="600"
              src={videoUrl}
              title="Entenda como funciona"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default PlayerDeVideoPrivado;
