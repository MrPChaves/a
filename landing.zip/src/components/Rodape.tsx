// src/components/Rodape.tsx
import React from 'react';
import styles from '../styles/Rodape.module.css'; // Importe o CSS Module para estilizar o rodapé

const Rodape: React.FC = () => {
  return (
    <footer className={styles.rodape}>
      <div className={styles.texto}>
        <p>Keeperstack 2024 © Todos Os Direitos Reservados</p>
        <p>Desenvolvido por [Zorbiun]</p>
      </div>
    </footer>
  );
};

export default Rodape;
