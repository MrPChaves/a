// src/components/JoinGroupSection.tsx
import React from 'react';
import styles from '../styles/JunteSeAoGrupo.module.css';

const JoinGroupSection: React.FC = () => {
  return (
    <section className={styles.container}>
      <div className={styles.card}>
        <div className={styles.textContent}>
          <p className={styles.text}>
            <span className={styles.whiteText}>Participe do grupo e se</span> 
            <strong className={styles.greenText}> mantenha atualizado. </strong>
            <span className={styles.whiteText}>Promoções e dicas.</span> 
          </p>
        </div>
        <div className={styles.buttonWrapper}>
          <button className={styles.joinButton}>Participe do grupo no WhatsApp!</button>
        </div>
      </div>
    </section>
  );
};

export default JoinGroupSection;
