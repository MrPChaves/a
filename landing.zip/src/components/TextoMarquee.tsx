// src/components/TextoMarquee.tsx
import React from 'react';
import styles from '../styles/TextoMarquee.module.css';

const TextoMarquee: React.FC = () => {
  return (
    <div className={styles.marqueeContainer}>
      <div className={styles.marqueeBackground} />
      <div className={styles.marqueeText}>
        Destrave o Primeiro Emprego... &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ative o modo Programador Desejado ...</div>
      
    </div>
  );
};

export default TextoMarquee;
