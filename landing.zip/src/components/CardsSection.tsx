// src/components/CardsSection.tsx
import React from 'react';
import styles from '../styles/CardsSection.module.css'; // Importa o CSS Module

const CardsSection: React.FC = () => {
  return (
    <div className={styles.Container}>
    <section className={styles.cardsSection}>
      <h1 className={styles.sectionTitle}>Se você deseja...</h1>
      <div className={styles.cardsContainer}>
        <div className={styles.card}>
          <div className={styles.cardIcon}>
            <i className="fas fa-file-alt"></i> {/* Exemplo de ícone */}
          </div>
          <h3 className={styles.cardTitle}>Ajustar seu Currículo</h3>
          <p className={styles.cardText}>Revise e otimize seu currículo para destacar suas habilidades e experiências mais relevantes. Garanta que o documento esteja claro, conciso e adaptado às vagas que você deseja alcançar. Encante os recrutadores e saia na frente desde o inicio!</p>
        </div>
        <div className={styles.card}>
          <div className={styles.cardIcon}>
            <i className="fas fa-network-wired"></i> {/* Exemplo de ícone */}
          </div>
          <h3 className={styles.cardTitle}>Ajuste Redes Sociais</h3>
          <p className={styles.cardText}>"Ajustar suas redes sociais, como GitHub e LinkedIn, etc..., para refletir suas habilidades e experiências. Inclua projetos relevantes e atualize seu perfil com as informações mais recentes. Demonstre seu código único com as melhores práticas"</p>
        </div>
        <div className={styles.card}>
          <div className={styles.cardIcon}>
            <i className="fas fa-user-cog"></i> {/* Exemplo de ícone */}
          </div>
          <h3 className={styles.cardTitle}>Alinhar Conhecimentos - Hard Skills</h3>
          <p className={styles.cardText}>"Ajuste seus conhecimentos de acordo com o perfil da vaga desejada. Destaque seus treinamentos, cursos concluídos, códigos de demonstração, certificados e habilidades específicas, alinhando-os às exigências do mercado e ao perfil da vaga pretendida."</p>
        </div>
        <div className={styles.card}>
          <div className={styles.cardIcon}>
            <i className="fas fa-lightbulb"></i> {/* Exemplo de ícone */}
          </div>
          <h3 className={styles.cardTitle}>"Ajuste Soft Skills - preparação para entrevistas"</h3>
          <p className={styles.cardText}>"Aprimore suas soft skills, como comunicação, trabalho em equipe e liderança. Estas habilidades são fundamentais para destacar-se em processos seletivos. Melhore sua atuação no ambiente de trabalho com competências valorizadas."</p>
        </div>
        <div className={styles.card}>
          <div className={styles.cardIcon}>
            <i className="fas fa-user-shield" ></i> {/* Exemplo de ícone */}
          </div>
          <h3 className={styles.cardTitle}>"Simulação de Entrevistas em 3 Níveis"</h3>
          <p className={styles.cardText}>Simule entrevistas em 3 níveis: Perguntas Técnicas, Técnica Algoritmos e Lógica e Técnica Revisão e Ajuste de Código. Prepare-se para enfrentar diferentes tipos de perguntas e situações em entrevistas reais."</p>
        </div>
        <div className={styles.card}>
          <div className={styles.cardIcon}>
            <i className="fas fa-dollar-sign" ></i> {/* Exemplo de ícone */}
          </div>
          <h3 className={styles.cardTitle}>"Preparação para Negociação"</h3>
          <p className={styles.cardText}>"Prepare-se para negociar custos, horários e condições. Aprenda técnicas e estratégias eficazes para uma negociação bem-sucedida. Alcance acordos favoráveis e maximize seus resultados obtendo o melhor possível"</p>
        </div>
      </div>
    </section>
    </div>
  );
};

export default CardsSection;
