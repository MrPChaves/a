// src/components/BeneficiosSection.tsx
import React from 'react';
import styles from '../styles/BeneficiosSection.module.css';

const BeneficiosSection: React.FC = () => {
  return (
    <section className={styles.beneficiosSection}>
      <div className={styles.container}>
        <h2 className={styles.title}>A partir de hoje começa a sua nova jornada de sucesso como programador  requisitado.</h2>
        <p className={styles.description}>
          Você vai finalmente aprender se destacar na stack desejada e atrair os recrutadores. 
          E mais que isso, ser aprovado com elogios pelos entrevistadores e muito bem avaliado pelos gestores onde atuar com está mentoria incrível que tem mudado vidas ...
        </p>
        <ul className={styles.benefitsList}>
          <li>
            <span>Criativos Premium em imagens e vídeos prontos para anunciar;</span>
            <span className={styles.price}>R$ 57,00</span>
          </li>
          <li>
            <span>Vídeos em formato de reels virais para o seu instagram profissional;</span>
            <span className={styles.price}>R$ 67,00</span>
          </li>
          <li>
            <span>Ideias infalíveis de Remarketing;</span>
            <span className={styles.price}>R$ 97,00</span>
          </li>
          <li>
            <span>Dicas das principais quebras de objeções da Maquininha TON;</span>
            <span className={styles.price}>R$ 47,00</span>
          </li>
          <li>
            <span>Grupo de Network;</span>
            <span className={styles.price}>R$ 197,00</span>
          </li>
          <li>
            <span>Dica de ouro para levantar caixa imediato com o tráfego orgânico;</span>
            <span className={styles.price}>R$ 67,00</span>
          </li>
          <li>
            <span>Suporte Exclusivo;</span>
            <span className={styles.price}>R$ 197,00</span>
          </li>
          <li>
            <span>E muito mais...</span>
          </li>
        </ul>
        <p className={styles.finalNote}>
          Se contar todo o conteúdo que está dentro do Criativos Premium ele custaria mais de R$700,00 porém você vai adquirir todo o treinamento por um valor especial :)
        </p>
      </div>
    </section>
  );
};

export default BeneficiosSection;
