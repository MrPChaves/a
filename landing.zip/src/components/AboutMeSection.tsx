// src/components/AboutMeSection.tsx
import React from 'react';
import Image from 'next/image';
import styles from '../styles/AboutMeSection.module.css';

const AboutMeSection: React.FC = () => {
  return (
    <section className={styles.container}>
      <h2 className={styles.title}>Olá! Sou Patrick, seu novo mentor!</h2>
      <div className={styles.content}>
        <div className={styles.imageWrapper}>
          <Image 
            src="/images/foto/patrickjpg.jpg" // Caminho para a sua imagem local
            alt="Patrick"
            width={400} // Largura da imagem
            height={500} // Altura da imagem
            className={styles.image}
          />
        </div>
        <div className={styles.textWrapper}>
          <p className={styles.text}>
            Tenho 51 anos e sou seu novo mentor! Com mais de 30 anos de experiência na área de tecnologia, minha missão é ajudar programadores a conquistarem seu primeiro emprego ou evoluírem para novos níveis na carreira. Estou aqui para guiá-lo em cada passo dessa jornada, oferecendo não apenas conhecimento técnico, mas também o suporte necessário para superar desafios e alcançar o sucesso.

            <br /><br />
             Iniciei na programação em 1988 aos 14 anos de idade e Formado em Análise de Sistemas em 1998, ao longo da minha carreira tive a oportunidade de trabalhar com algumas das maiores empresas do mundo, como Santander, Bradesco, Itaú, Caixa, Banco Carrefour, Avanade, Accenture, McDonald's, entre outros 63 líderes de mercado nacionais e internacionais. Essa experiência me permitiu entender profundamente as demandas e expectativas do mercado, e agora quero compartilhar esse conhecimento com você.

            <br /><br />
            Meu objetivo é proporcionar a você todas as ferramentas e estratégias necessárias para não apenas entrar no mercado de trabalho, mas também se destacar nele. Vou literalmente pegar na sua mão e colocar meu esforço total para te ajudar a conquistar novos níveis. Juntos, vamos transformar dificuldades em conquistas, e você verá que é possível receber elogios por suas habilidades e técnicas em qualquer empresa aplicando o que vou te ensinar.

            <br /><br />
          Se você está pronto para dar o próximo passo em sua carreira, estou aqui para te apoiar. Vamos juntos alcançar patamares de sucesso que você nunca imaginou! Não há tempo a perder – BORA LÁ!!!
         </p>

          <button className={styles.accessButton}>Quero ter acesso!</button>
        </div>
      </div>
    </section>
  );
};

export default AboutMeSection;
