// src/components/BotaoMeTornarDesejado.tsx
import React from 'react';
import styles from '../styles/BotaoMeTornarDesejado.module.css'; // Importa o CSS Module

interface BotaoMeTornarDesejadoProps {
  onClick: () => void;
}

const BotaoMeTornarDesejado: React.FC<BotaoMeTornarDesejadoProps> = ({ onClick }) => {
  return (
    <div className={styles.container}>
    <button className={styles.button} onClick={onClick}>
      Eu Quero Me Tornar o Profissional Desejado
    </button>
    </div>
  );
};

export default BotaoMeTornarDesejado;
