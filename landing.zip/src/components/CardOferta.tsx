// src/components/CardOferta.tsx
import React from 'react';
import styles from '../styles/CardOferta.module.css';

const CardOferta: React.FC = () => {
  return (
    <div className={styles.cardContainer}>
    <div className={styles.cardOferta}>
      <h3 className={styles.titulo}>Oferta Exclusiva:</h3>
      <p className={styles.precoAntigo}>De <span>R$699,00</span> por apenas:</p>
      <p className={styles.precoAtual}>R$ 77,00</p>
      <p className={styles.parcelamento}>Ou 12x de R$7,73</p>
      <button className={styles.botao}>Adquirir Agora!</button>
    </div>
    </div>
  );
};

export default CardOferta;
