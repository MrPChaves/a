// src/components/FAQSection.tsx
import React, { useState } from 'react';
import styles from '../styles/FAQSection.module.css';

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "Como funciona o treinamento?",
    answer: "O treinamento é composto por vídeo-aulas, material de apoio e exercícios práticos para que você possa aplicar o conhecimento adquirido."
  },
  {
    question: "Por quanto tempo terei acesso ao conteúdo?",
    answer: "Você terá acesso vitalício ao conteúdo, podendo revisitar as aulas sempre que precisar."
  },
  {
    question: "Há suporte disponível durante o treinamento?",
    answer: "Sim, oferecemos suporte através de um grupo exclusivo onde você pode tirar dúvidas e interagir com outros alunos."
  },
  {
    question: "Posso pagar em parcelas?",
    answer: "Sim, oferecemos a opção de pagamento parcelado em até 12 vezes no cartão de crédito."
  },
  {
    question: "Há certificado de conclusão?",
    answer: "Sim, ao final do treinamento você receberá um certificado de conclusão reconhecido no mercado."
  }
];

const FAQSection: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className={styles.faqSection}>
      <h2 className={styles.title}>Perguntas Frequentes</h2>
      <div className={styles.faqContainer}>
        {faqData.map((item, index) => (
          <div
            key={index}
            className={`${styles.faqItem} ${activeIndex === index ? styles.active : ''}`}
            onClick={() => toggleFAQ(index)}
          >
            <div className={styles.question}>
              {item.question}
            </div>
            <div className={styles.answer} style={{ maxHeight: activeIndex === index ? '500px' : '0' }}>
              {item.answer}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQSection;
