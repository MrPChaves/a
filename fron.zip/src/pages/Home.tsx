// src/pages/Home.tsx
import React, { useState } from 'react';
import Map from '../components/Map';

const Home: React.FC = () => {
  // Remova setMarkers se não for usado
  const [markers] = useState<{ id: number; lat: number; lng: number }[]>([
    { id: 1, lat: -23.5505, lng: -46.6333 }, // Exemplo de pino
    // Adicione mais pinos conforme necessário
  ]);

  return (
    <div>
      <h1>Bem-vindo à Página Inicial!</h1>
      <p>Veja o mapa e interaja com os pinos cadastrados.</p>
      <Map markers={markers} />
    </div>
  );
};

export default Home;
