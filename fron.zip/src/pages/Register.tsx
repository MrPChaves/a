// src/pages/Register.tsx
import React, { useState } from 'react';
import axios from 'axios'; // Certifique-se de ter o axios instalado
import './LocationForm.css'; // Certifique-se de que o CSS está no mesmo diretório ou ajuste o caminho

const Register: React.FC = () => {
  const [name, setName] = useState('');
  const [cep, setCep] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const locationData = { name, cep, latitude: parseFloat(latitude), longitude: parseFloat(longitude) };

    try {
      const response = await axios.post('http://194.140.199.139:3002/locations', locationData);
      console.log('Localização cadastrada com sucesso:', response.data);
      // Opcional: Limpar o formulário após o sucesso
      setName('');
      setCep('');
      setLatitude('');
      setLongitude('');
    } catch (error) {
      console.error('Erro ao cadastrar localização:', error);
    }
  };

  return (
    <div className="form-container">
      <h2>Cadastro de Localização</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Nome:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="cep">CEP:</label>
          <input
            type="text"
            id="cep"
            value={cep}
            onChange={(e) => setCep(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="latitude">Latitude:</label>
          <input
            type="number"
            id="latitude"
            value={latitude}
            onChange={(e) => setLatitude(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="longitude">Longitude:</label>
          <input
            type="number"
            id="longitude"
            value={longitude}
            onChange={(e) => setLongitude(e.target.value)}
            required
          />
        </div>
        <div className="button-container">
          <button type="submit">Cadastrar</button>
        </div>
      </form>
    </div>
  );
};

export default Register;
