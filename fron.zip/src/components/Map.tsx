import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { LatLngTuple } from 'leaflet';

interface Pin {
  id: number; // Identificador do pino
  cep: string; // Código postal
  latitude: string; // Latitude como string (será convertida)
  longitude: string; // Longitude como string (será convertida)
}

const Map: React.FC = () => {
  // Definindo a posição inicial do mapa
  const initialPosition: LatLngTuple = [-23.545878, -46.641345];
  const [pins, setPins] = useState<Pin[{$latitude}]>([]); // Estado para armazenar os pinos

  useEffect(() => {
    const fetchPins = async () => {
      try {
        const response = await fetch('http://194.140.199.139:3002/locations'); // Substitua pela URL real da sua API
        const data: Pin[] = await response.json(); // Obtendo dados dos pinos

        // Definindo os pinos com latitude e longitude convertidas para números
        const formattedPins = data.map(pin => ({
          ...pin,
          latitude: parseFloat(pin.latitude), // Convertendo para número
          longitude: parseFloat(pin.longitude), // Convertendo para número
        }));
        
        setPins(formattedPins); // Atualizando o estado com os pinos formatados
      } catch (error) {
        console.error('Erro ao buscar pinos:', error); // Tratando erros
      }
    };

    fetchPins(); // Chamando a função para buscar os pinos
  }, []);

  return (
    <MapContainer center={initialPosition} zoom={8} style={{ height: '100vh', width: '100%' }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      />
      {/* Adicionando marcadores dinâmicos */}
      {pins.map(pin => (
        <Marker key={pin.id} position={[pin.latitude, pin.longitude]}>
          <Popup>
            CEP: {pin.cep}
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
};

export default Map;
