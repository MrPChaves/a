import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from './user/user.module';
import { LocationModule } from './location/location.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'admingeo', // seu usuário do PostgreSQL
      password: 'admingeo', // sua senha do PostgreSQL
      database: 'apigeo', // seu banco de dados
      entities: [__dirname + '/**/*.entity{.ts,.js}'],
      synchronize: true,
    }),
    UserModule,
    LocationModule,
  ],
})
export class AppModule {}
