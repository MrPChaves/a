<?php
// register.php - Cadastro de usuário

require_once 'db.php'; // Incluir a conexão com o banco de dados

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obter dados do formulário
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    // Validar os dados
    if (!empty($username) && !empty($email) && !empty($password)) {
        // Hash da senha
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Inserir dados no banco de dados
        $sql = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
        $stmt = $pdo->prepare($sql);

        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);

        try {
            $stmt->execute();
            echo "Cadastro realizado com sucesso!";
        } catch (PDOException $e) {
            echo "Erro ao cadastrar: " . $e->getMessage();
        }
    } else {
        echo "Todos os campos devem ser preenchidos!";
    }
}
?>

<!-- Formulário de cadastro -->
<form method="POST" action="register.php">
    <label for="username">Usuário:</label>
    <input type="text" name="username" required><br>

    <label for="email">E-mail:</label>
    <input type="email" name="email" required><br>

    <label for="password">Senha:</label>
    <input type="password" name="password" required><br>

    <button type="submit">Cadastrar</button>
</form>
