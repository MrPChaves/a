<?php
// db.php - Configuração de conexão com o PostgreSQL
$host = 'db'; // Nome do serviço no docker-compose.yml
$dbname = 'mydatabase';
$user = 'myuser';
$pass = 'mypassword';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão com o banco de dados: " . $e->getMessage());
}
?>
