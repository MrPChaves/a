<?php
// Verificar se o usuário está logado (se estiver, mostrar a página)
session_start();

// Verificar se a sessão de login está ativa
if (!isset($_SESSION['username'])) {
    // Se não estiver logado, redirecionar para a página de login
    header("Location: /home/index.html");
    exit;
}

// Recuperar o nome do usuário da sessão
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard :: Syspay Digital</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="welcome-message">
            <h1>Bem-vindo, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>Você está logado no Syspay Digital.</p>
        </div>
        
        <!-- Links de navegação ou outras áreas -->
        <div class="nav-links">
            <a href="/home/profile.php" class="btn">Visitar Perfil</a>
            <a href="/home/logout.php" class="btn btn-logout">Sair</a>
        </div>
    </div>
</body>
</html>
