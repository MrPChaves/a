<?php
// login.php - Login de usuário

require_once 'db.php'; // Incluir a conexão com o banco de dados

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obter dados do formulário
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    // Validar os dados
    if (!empty($username) && !empty($password)) {
        // Verificar se o usuário existe
        $sql = "SELECT * FROM users WHERE username = :username LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            echo "Login bem-sucedido!";
            // Redirecionar para a página inicial ou dashboard
            // header("Location: /home/dashboard.php");
        } else {
            echo "Usuário ou senha inválidos!";
        }
    } else {
        echo "Preencha todos os campos!";
    }
}
?>

<!-- Formulário de login -->
<form method="POST" action="login.php">
    <label for="username">Usuário:</label>
    <input type="text" name="username" required><br>

    <label for="password">Senha:</label>
    <input type="password" name="password" required><br>

    <button type="submit">Login</button>
</form>
